import { GraphQLEnumType, GraphQLSchema, OperationDefinitionNode, TypeNode, VariableDefinitionNode } from 'graphql';
import { OpenAPIV3 } from 'openapi-types';
import { OpenAPIBuildPathFromOperationOpts } from '../types.js';
export declare function buildPathFromOperation({ url, schema, operation, useRequestBody, tags, description, customScalars, exampleDirective, exampleDirectiveParser, }: OpenAPIBuildPathFromOperationOpts): OpenAPIV3.OperationObject;
export declare function resolveEnumType(enumType: GraphQLEnumType): Record<string, any>;
export declare function resolveRequestBody(variables: ReadonlyArray<VariableDefinitionNode> | undefined, schema: GraphQLSchema, operation: OperationDefinitionNode, opts: Pick<OpenAPIBuildPathFromOperationOpts, 'customScalars' | 'exampleDirective' | 'exampleDirectiveParser'> & {
    enumTypes: Record<string, any>;
}): {};
export declare function resolveParamSchema(type: TypeNode, opts: Pick<OpenAPIBuildPathFromOperationOpts, 'schema' | 'customScalars' | 'exampleDirective' | 'exampleDirectiveParser'> & {
    enumTypes: Record<string, any>;
}): any;
export declare function resolveResponse({ schema, operation, opts, }: {
    schema: GraphQLSchema;
    operation: OperationDefinitionNode;
    opts: Pick<OpenAPIBuildPathFromOperationOpts, 'customScalars' | 'exampleDirective' | 'exampleDirectiveParser'>;
}): any;
export declare function isInPath(url: string, param: string): boolean;
export declare function resolveVariableDescription(schema: GraphQLSchema, operation: OperationDefinitionNode, variable: VariableDefinitionNode): string | undefined;
