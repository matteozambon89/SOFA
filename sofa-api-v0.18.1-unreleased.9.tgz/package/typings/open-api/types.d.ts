import { GraphQLObjectType, GraphQLInputObjectType, GraphQLType } from 'graphql';
import { Sofa } from '../sofa.js';
export declare function buildSchemaObjectFromType(type: GraphQLObjectType | GraphQLInputObjectType, opts: Pick<Sofa, 'schema' | 'customScalars' | 'exampleDirective' | 'exampleDirectiveParser'>): any;
export declare function resolveFieldType(type: GraphQLType, opts: Pick<Sofa, 'schema' | 'customScalars' | 'exampleDirective' | 'exampleDirectiveParser'>): any;
