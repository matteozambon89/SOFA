export declare const BatchItemComponent: {
    type: string;
    properties: {
        path: {
            type: string;
            format: string;
            description: string;
            example: string;
        };
        method: {
            type: string;
            enum: string[];
            description: string;
            example: string;
        };
        params: {
            type: string;
            description: string;
            additionalProperties: boolean;
            example: {
                prop1: string;
                prop2: string;
            };
        };
    };
    additionalProperties: boolean;
    required: string[];
};
export declare const BatchResponseErrorComponent: {
    type: string;
    properties: {
        errors: {
            type: string;
            items: {
                type: string;
                properties: {
                    message: {
                        type: string;
                        description: string;
                    };
                };
                required: string[];
            };
            minItems: number;
            maxItems: number;
        };
    };
    required: string[];
    example: {
        errors: {
            message: string;
        }[];
    };
};
export declare const BatchResponseItemSuccessComponent: {
    type: string;
    properties: {
        status: {
            type: string;
            example: number;
            default: number;
            description: string;
        };
        data: {
            description: string;
            oneOf: ({
                type: string;
                example: {
                    strProp: string;
                    intProp: number;
                };
                additionalProperties: boolean;
                items?: undefined;
            } | {
                type: string;
                items: {};
                example: {
                    strProp: string;
                    intProp: number;
                }[];
                additionalProperties?: undefined;
            })[];
        };
    };
    required: string[];
};
export declare const BatchResponseItemErrorComponent: {
    type: string;
    properties: {
        status: {
            type: string;
            example: number;
            description: string;
        };
        errors: {
            type: string;
            items: {
                type: string;
                properties: {
                    message: {
                        type: string;
                        description: string;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            minItems: number;
            maxItems: number;
            example: {
                message: string;
            }[];
        };
    };
    required: string[];
};
