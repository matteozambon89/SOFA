import { OpenAPIV3 } from 'openapi-types';
import { Sofa } from '../sofa.js';
export declare function mapToPrimitive(type: string): any;
export declare function mapToRef(type: string): string;
export declare function normalizePathParamForOpenAPI(path: string): string;
export declare function addExampleFromDirective(component: OpenAPIV3.SchemaObject, node: any, opts: Pick<Sofa, 'schema' | 'exampleDirective' | 'exampleDirectiveParser'>): OpenAPIV3.SchemaObject;
