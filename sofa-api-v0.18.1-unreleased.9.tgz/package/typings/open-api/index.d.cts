import { OpenAPIConfig, RouteInfo } from '../types.cjs';
import { OpenAPIV3 } from 'openapi-types';
export declare function OpenAPI({ schema, info, servers, components, security, tags, customScalars, exampleDirective, exampleDirectiveParser, }: OpenAPIConfig): {
    addRoute(info: RouteInfo, config?: {
        basePath?: string;
    }): void;
    get(): OpenAPIV3.Document<{}>;
};
