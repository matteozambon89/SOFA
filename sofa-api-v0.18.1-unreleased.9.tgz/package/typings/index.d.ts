import type { SofaConfig } from './sofa.js';
export { OpenAPI } from './open-api/index.js';
export declare function useSofa(config: SofaConfig): import("fets").Router<any, {}, {
    [TKey: string]: never;
}>;
