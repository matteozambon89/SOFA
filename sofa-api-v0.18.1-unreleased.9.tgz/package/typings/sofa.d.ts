import { GraphQLSchema, subscribe, execute } from 'graphql';
import { Ignore, ContextFn, ContextValue, ExampleDirectiveParser } from './types.js';
import { ErrorHandler } from './router.js';
import { HTTPMethod, StatusCode } from 'fets/typings/typed-fetch';
import { RouterOpenAPIOptions, RouterSwaggerUIOptions } from 'fets';
export interface RouteConfig {
    method?: HTTPMethod;
    path?: string;
    responseStatus?: StatusCode;
    tags?: string[];
    description?: string;
}
export interface Route {
    method: HTTPMethod;
    path: string;
    responseStatus: StatusCode;
}
export type SofaBatchingConfig = boolean | {
    /**
     * You can limit the number of batched operations per request.
     *
     * @default 10
     */
    limit?: number;
};
export type SofaBatching = {
    enabled: boolean;
    limit: number;
};
export interface SofaConfig {
    basePath: string;
    schema: GraphQLSchema;
    execute?: typeof execute;
    subscribe?: typeof subscribe;
    /**
     * Treats an Object with an ID as not a model.
     * @example ["User", "Message.author"]
     */
    ignore?: Ignore;
    depthLimit?: number;
    errorHandler?: ErrorHandler;
    /**
     * Overwrites the default HTTP route.
     */
    routes?: Record<string, RouteConfig>;
    context?: ContextFn | ContextValue;
    customScalars?: Record<string, any>;
    enumTypes?: Record<string, any>;
    exampleDirective?: string;
    exampleDirectiveParser?: ExampleDirectiveParser;
    batching?: SofaBatchingConfig;
    openAPI?: RouterOpenAPIOptions<any>;
    swaggerUI?: RouterSwaggerUIOptions;
}
export interface Sofa {
    basePath: string;
    schema: GraphQLSchema;
    models: string[];
    ignore: Ignore;
    depthLimit: number;
    routes?: Record<string, RouteConfig>;
    execute: typeof execute;
    subscribe: typeof subscribe;
    errorHandler?: ErrorHandler;
    contextFactory: ContextFn;
    customScalars: Record<string, any>;
    enumTypes: Record<string, any>;
    exampleDirective?: string;
    exampleDirectiveParser?: ExampleDirectiveParser;
    batching: SofaBatching;
    openAPI?: RouterOpenAPIOptions<any>;
    swaggerUI?: RouterSwaggerUIOptions;
}
export declare function createSofa(config: SofaConfig): Sofa;
export declare function isContextFn(context: any): context is ContextFn;
