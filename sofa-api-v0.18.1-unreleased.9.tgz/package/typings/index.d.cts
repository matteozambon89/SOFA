import type { SofaConfig } from './sofa.cjs';
export { OpenAPI } from './open-api/index.cjs';
export declare function useSofa(config: SofaConfig): import("fets").Router<any, {}, {
    [TKey: string]: never;
}>;
